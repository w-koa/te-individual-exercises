package com.techelevator.zinogreFanSite.daomodel;

public class HitzoneData {
	
	// Attributes
	private int id;
	private String part;
	private int sever;
	private int blunt;
	private int ranged;
	private int fire;
	private int water;
	private int thunder;
	private int ice;
	private int dragon;
	private int stun;
	
	// Gets and Sets
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getPart() {
		return part;
	}
	public void setPart(String part) {
		this.part = part;
	}
	public int getSever() {
		return sever;
	}
	public void setSever(int sever) {
		this.sever = sever;
	}
	public int getBlunt() {
		return blunt;
	}
	public void setBlunt(int blunt) {
		this.blunt = blunt;
	}
	public int getRanged() {
		return ranged;
	}
	public void setRanged(int ranged) {
		this.ranged = ranged;
	}
	public int getFire() {
		return fire;
	}
	public void setFire(int fire) {
		this.fire = fire;
	}
	public int getWater() {
		return water;
	}
	public void setWater(int water) {
		this.water = water;
	}
	public int getThunder() {
		return thunder;
	}
	public void setThunder(int thunder) {
		this.thunder = thunder;
	}
	public int getIce() {
		return ice;
	}
	public void setIce(int ice) {
		this.ice = ice;
	}
	public int getDragon() {
		return dragon;
	}
	public void setDragon(int dragon) {
		this.dragon = dragon;
	}
	public int getStun() {
		return stun;
	}
	public void setStun(int stun) {
		this.stun = stun;
	}
	
}
